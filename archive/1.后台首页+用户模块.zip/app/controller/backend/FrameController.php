<?php
/**
 * 传智播客：高端PHP培训
 * 网站：http://www.itcast.cn
 */
namespace app\controller\backend;

use core\BaseController;

class FrameController extends BaseController
{
    // 骨架页
    public function index()
    {
        $this->loadView('backend/frame/index');
    }

    // 左侧菜单
    public function left()
    {
        $this->loadView('backend/frame/left');
    }

    // 内容页
    public function content()
    {
        $this->loadView('backend/frame/content');
    }

    // 顶部导航
    public function top()
    {
        $this->loadView('backend/frame/top');
    }
}