<?php
/**
 * 传智播客：高端PHP培训
 * 网站：http://www.itcast.cn
 */
require 'core/Application.php';
use core\Application;

Application::run();