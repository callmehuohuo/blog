<?php
/**
 * 传智播客：高端PHP培训
 * 网站：http://www.itcast.cn
 */
namespace app\model;

class UserModel extends \core\BaseModel
{
    public static $table = 'user';

    // 返回所有的用户
    public function getUsers()
    {
        return $this->selectAll('user');
    }

    // 返回所有的产品
    public function getProducts()
    {
        return $this->selectAll('product');
    }

    // 添加用户
    public function addUser($username, $nickname, $email)
    {
        $sql = "INSERT INTO `user` VALUES (null, '$username', '$email', '', '$nickname', 0, '')";
        return $this->db->exec($sql);
    }

    // 查询一个用户的详情
    public function getUser($id)
    {
        $sql = "SELECT * FROM `user` WHERE id=$id";
        return $this->db->getOne($sql);
    }

    // 修改一个用户的信息
    public function updateUser($id, $username, $nickname, $email)
    {
        $sql = "UPDATE `user` SET username='$username', email='$email', nickname='{$nickname}' WHERE id=$id";
        return $this->db->exec($sql);
    }
}











