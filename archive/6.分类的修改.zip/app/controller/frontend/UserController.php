<?php
/**
 * 传智播客：高端PHP培训
 * 网站：http://www.itcast.cn
 */
namespace app\controller\frontend;

class UserController extends \core\BaseController
{
    public function modifyInformation()
    {
        echo '修改我的个人资料';
    }
}