<?php
/**
 * 传智播客：高端PHP培训
 * 网站：http://www.itcast.cn
 */
namespace core;

class BaseController
{
    protected function redirect($w, $u, $m)
    {
        header("Refresh:{$w};url={$u}");
        echo $m;
    }

    // 加载视图
    public function loadView($view, $arr = array())
    {
        foreach($arr as $key => $value) {
            // $key => $users
            $$key = $value;
        }
        require VIEW . "{$view}.html";
    }
}






