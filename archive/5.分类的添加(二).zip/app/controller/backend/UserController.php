<?php
/**
 * 传智播客：高端PHP培训
 * 网站：http://www.itcast.cn
 */

namespace app\controller\backend;

use app\model\UserModel;

class UserController extends \core\BaseController
{
    public function delete()
    {
        $id = $_GET['id'];

        if (UserModel::build()->deleteOne($id) > 0) {
            $this->redirect(3, 'index.php?p=backend&c=User&a=index', '删除成功。');
        } else {
            $this->redirect(3, 'index.php?p=backend&c=User&a=index', '删除失败。');
        }
    }

    public function index()
    {
        // new UserModel()
        $userModel = UserModel::build();
        // 显示用户列表
        // 1. 调用模型
        $users = $userModel->selectAll();
        $helloworld = 'hello world';
        $arr = array(
            'users' => $users,
            'helloworld' => $helloworld
        );
        // 2. 调用视图
        $this->loadView('backend/UserIndex', $arr);
    }

    public function add()
    {
        if (isset($_POST['submit'])) {
            $username = $_POST['Username'];
            $nickname = $_POST['Nickname'];
            $email = $_POST['Email'];

            if (UserModel::build()->addUser($username, $nickname, $email) == 1) {
                // 添加成功
                $this->redirect(3, '?p=backend&c=User&a=index', '添加成功');
            } else {
                // 添加失败
                $this->redirect(3, '?p=backend&c=User&a=add', '添加失败');
            }
        } else {
            $this->loadView('backend/UserAdd');
        }
    }

    // 修改用户
    public function update()
    {
        $id = $_GET['id'];
        if (isset($_POST['submit'])) {
            // 接收修改后的用户的信息
            $username = $_POST['Username'];
            $nickname = $_POST['Nickname'];
            $email = $_POST['Email'];

            // 修改后的值输入数据库
            if (UserModel::build()->updateUser($id, $username, $nickname, $email) == 1) {
                // 修改成功
                $this->redirect(3, '?p=backend&c=User&a=index', '修改成功');
            } else {
                // 修改失败
                $this->redirect(3, "?p=backend&c=User&a=update&id=$id", '修改失败');
            }
        } else {
            // 获取一个用户的信息
            $user = UserModel::build()->getUser($id);
            $arr = array(
                'user' => $user,
            );
            $this->loadView('backend/update', $arr);
        }
    }
}














