<?php

namespace app\controller\backend;

use app\model\CategoryModel;
use core\BaseController;

// 分类管理功能
class CategoryController extends BaseController
{
    // 分类列表功能
    public function index()
    {
        // CategoryController使用CategoryModel从category取数据出来，CategoryController使用index.html显示数据
        $categories = CategoryModel::build()->selectAll();
        // 计算分类所在的级别
        $categories = CategoryModel::build()->level($categories);// 分类新加一个level表示分类的级别
        $this->loadView('backend/category/index', array(
            'categories' => $categories,// $categories传递到模版
        ));
    }

    // 删除一个分类
    public function delete()
    {
        $id = $_GET['id'];

        // 下级的数量大于0，提示不允许删除
        if (CategoryModel::build()->countSub($id) > 0) {
            $this->redirect(3, '?p=backend&c=Category&a=index', '不允许删除。');
            exit();
        }

        if (CategoryModel::build()->deleteOne($id) === true) {
            // 删除成功
            $this->redirect(3, '?p=backend&c=Category&a=index', '删除成功。');
        } else {
            // 删除失败
            $this->redirect(3, '?p=backend&c=Category&a=index', '删除失败。');
        }
    }

    // 添加一个分类
    public function add()
    {
        if (isset($_POST['submit'])) {
            // 提交了表单
            $name = $_POST['Name'];
            $nickname = $_POST['Alias'];
            $sort = $_POST['Order'];
            $parentId = $_POST['ParentID'];

            if (CategoryModel::build()->addOne(array(
                'name' => $name,
                'nickname' => $nickname,
                'sort' => $sort,
                'parent_id' => $parentId,
            ))) {
                // 添加成功
                $this->redirect(3, '?p=backend&c=Category&a=index', '添加成功。');
            } else {
                // 添加失败
                $this->redirect(3, '?p=backend&c=Category&a=add', '添加失败。');
            }
        } else {
            // 没有提交表单，显示表单
            $categories = CategoryModel::build()->selectAll();
            // 对分类进行分级：level，又称为无限极分类, 无限极分类算法
            $categories = CategoryModel::build()->level($categories);
            $this->loadView('backend/category/add', array(
                'categories' => $categories,
            ));
        }
    }
}















