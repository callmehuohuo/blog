<?php
/**
 * 传智播客：高端PHP培训
 * 网站：http://www.itcast.cn
 */



namespace app\controller\backend;

use app\model\UserModel;
use core\BaseController;
use vendor\Captcha;

class LoginController extends BaseController
{
    public function login()
    {
        if (isset($_POST['btnPost'])) {
            // 提交表单
            $username = $_POST['username'];
            $username = addslashes($username);// 防sql注入攻击
            $password = $_POST['password'];
            $captcha = $_POST['edtCaptcha'];
            if ($captcha === $_SESSION['captchaCode']) {
                // 一样
            } else {
                // 不一样
                return $this->redirect(3, '?p=backend&c=Login&a=login', '验证码错误。');
            }
            // var_dump($username, $password);
            $user = UserModel::build()->selectOneBy("password='$password' AND username='$username' ");// $user可能找不到，用户名/密码错误了
            // var_dump($user);
            if ($user === false) {
                $_SESSION['loginSuccess'] = false;
                // 登录失败
                $this->redirect(3, '?p=backend&c=Login&a=login', '登陆失败。');
            } else {
                // 登录成功
                $_SESSION['loginSuccess'] = true;
                $this->redirect(3, '?p=backend&c=Frame&a=index', '登录成功。');
            }
        } else {
            // 显示登陆页面
            $this->loadView('backend/login/login');
        }
    }

    public function logout()
    {
        // 修改/删除 $_SESSION 里的loginSuccess下标
        // $_SESSION['loginSuccess'] = false;
        // unset($_SESSION['loginSuccess']);
        $_SESSION = array();// 清空session，防止其它逻辑代码使用$_SESSION时的逻辑错误
        session_destroy();// 下一次请求时影响$_SESSION,不影响本次请求
        // 退出成功后跳转到登录页面
        $this->redirect(3, '?p=backend&c=Login&a=login', '退出成功。');
    }

    // 输出验证码图片
    public function captcha()
    {
        $captcha = new Captcha();
        $captcha->generateCode();// 输出验证码图片
        $_SESSION['captchaCode'] = $captcha->getCode();
    }
}































