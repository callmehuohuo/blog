<?php
/**
 * 传智播客：高端PHP培训
 * 网站：http://www.itcast.cn
 */

namespace core;

// 项目启动类
class Application
{
    // 对框架的流程按顺序调用
    public static function run()
    {
        self::defineConst();
        self::defineAutoload();
        self::setCharset();
        self::openSession();
        self::routeDispatch();
    }

    // 定义常用常量
    private static function defineConst() {
        $type = isset($_GET['a']) ? $_GET['a'] : 'index';
        $c = isset($_GET['c']) ? $_GET['c'] : 'User';
        // 接收平台的参数, frontend表示前台 backend表示后台
        $p = isset($_GET['p']) ? $_GET['p'] : 'frontend';
        // 重要的参数
        define('PLATFORM', $p);
        define('CONTROLLER', $c);
        define('ACTION', $type);
        define('DS', '/');
        // 重复的路径
        define('ROOT', './');// 项目根目录
        define('CORE', ROOT . 'core/');// 核心文件目录
        define('APP', ROOT . 'app/');// ./app
        define('VIEW', APP . 'view/');// 视图目录
    }

    // 定义自动加载
    private static function defineAutoload()
    {
        spl_autoload_register('self::autoload');
    }

    private static function autoload($className)
    {
        // echo $className . '还没有加载，正在加载中，请稍等....<br />';
        require "./" . str_replace('\\', '/', $className) . ".php";
    }

    // 设置字符集
    private static function setCharset()
    {
        header('Content-Type:text/html;charset=utf-8');
    }

    // 开启session
    private static function openSession()
    {
        session_start();
    }

    // 路由分发
    private static function routeDispatch()
    {
        $c= CONTROLLER;
        $type = ACTION;
        $p = PLATFORM;
        $c .= 'Controller';
        $c = "\\app\\controller\\{$p}\\" . $c;
        $controller = new $c();// new \app\controller\backend\UserController, new ProductController, new ...
        $controller->$type();
    }
}










